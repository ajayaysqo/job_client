const cron = require('node-cron');
const jobImportQueue = require('../queues/jobImportQueue');

const FEEDS = [
  'https://jobicy.com/?feed=job_feed',
  'https://jobicy.com/?feed=job_feed&job_categories=smm&job_types=full-time',
  'https://jobicy.com/?feed=job_feed&job_categories=seller&job_types=full-time&search_region=france',
  'https://jobicy.com/?feed=job_feed&job_categories=design-multimedia',
  'https://jobicy.com/?feed=job_feed&job_categories=data-science',
  'https://jobicy.com/?feed=job_feed&job_categories=copywriting',
  'https://jobicy.com/?feed=job_feed&job_categories=business',
  'https://jobicy.com/?feed=job_feed&job_categories=management',
  'https://www.higheredjobs.com/rss/articleFeed.cfm'
];

function addFeedsToQueue() {
  console.log('Adding all feeds to queue NOW...');
  FEEDS.forEach(url => {
    jobImportQueue.add('import-feed', { url }, {
      attempts: 3,
      backoff: { type: 'exponential', delay: 2000 }
    });
    console.log(`Queued: ${url}`);
  });
}

function scheduleHourlyImport() {
  cron.schedule('0 * * * *', addFeedsToQueue);
}

module.exports = { scheduleHourlyImport, addFeedsToQueue };